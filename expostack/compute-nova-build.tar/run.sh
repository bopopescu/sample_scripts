#!/bin/bash



salt_install() {

        current_dir=$(pwd)

	if [ $region_flag -eq 2 ]
                then
			DOMAIN="scl1"
	else
		if [ $region_flag -eq 1 ]
		then
			DOMAIN="la1"
		fi
	fi

        #echo $current_dir
        tar xvf $current_dir/salt.tar
        cd $current_dir/salt
        $current_dir/salt/install_saltminion.sh ubuntu dev $DOMAIN
}


net_filter_config () {

	if [ -w /etc/sysctl.conf ]
	then
		sysctl_1=$(cat /etc/sysctl.conf | grep "net.ipv4.conf.all.rp_filter=0")

		if [ -z "$sysctl_1" ]
		then
			echo "net.ipv4.conf.all.rp_filter=0" >> /etc/sysctl.conf
		else
			echo $sysctl_1|grep "#"
			if [ $? -eq 0 ]
			then
				echo "net.ipv4.conf.all.rp_filter=0" >> /etc/sysctl.conf
			else
                                echo "sysctl entry found: net.ipv4.conf.all.rp_filter=0"
			fi
		fi

		sysctl_2=$(cat /etc/sysctl.conf | grep "net.ipv4.conf.default.rp_filter=0")

		if [ -z "$sysctl_2" ]
                then
			echo "net.ipv4.conf.default.rp_filter=0" >> /etc/sysctl.conf
		else
			echo $sysctl_2|grep "#"
			if [ $? -eq 0 ]
                	then
				echo "net.ipv4.conf.default.rp_filter=0" >> /etc/sysctl.conf
			else
				echo "sysctl entry found: net.ipv4.conf.default.rp_filter=0"
			fi
		fi

		sysctl_3=$(cat /etc/sysctl.conf | grep "net.bridge.bridge-nf-call-iptables=1")
	
		if [ -z "$sysctl_3" ]
		then
			echo "net.bridge.bridge-nf-call-iptables=1" >> /etc/sysctl.conf
		else
			echo $sysctl_3|grep "#"
			if [ $? -eq 0 ]
                	then
				echo "net.bridge.bridge-nf-call-iptables=1" >> /etc/sysctl.conf
			else
				echo "sysctl entry found: net.bridge.bridge-nf-call-iptables=1"
			fi
		fi

		sysctl_4=$(cat /etc/sysctl.conf | grep "net.bridge.bridge-nf-call-ip6tables=1")

		if [ -z "$sysctl_4" ]
		then
			echo "net.bridge.bridge-nf-call-ip6tables=1" >> /etc/sysctl.conf
		else
			echo $sysctl_4|grep "#"
			if [ $? -eq 0 ]
			then	
				echo "net.bridge.bridge-nf-call-ip6tables=1" >> /etc/sysctl.conf
			else
				echo "sysctl entry found: net.bridge.bridge-nf-call-ip6tables=1"
			fi
		fi	
	fi

	if [ -w /etc/modules ]
	then
		modules=$(cat /etc/modules|grep "br_netfilter")

		if [ -z "$modules" ]
		then			
			echo "br_netfilter" >> /etc/modules
		else
			echo $modules|grep "#"
			if [ $? -eq 0 ]
                	then	
				echo "br_netfilter" >> /etc/modules
			else
				echo "Entry found in /etc/modules: br_netfilter"
			fi
		fi
	fi
}

region () {

	if [ -w /etc/ceilometer/ceilometer.conf ]
	then
		if [ $region_flag -eq 2 ]
		then
			rabbit_userid="rabbit_userid = expo_stack"
			os_region_name="os_region_name = SCL1"
			echo "Making ceilometer regional changes ....... "
			rabbit_user=$(grep -n "rabbit_userid = expo" /etc/ceilometer/ceilometer.conf|cut -d ':' -f1)
			sed -i "${rabbit_user}d" /etc/ceilometer/ceilometer.conf
			sed -i "${rabbit_user}i$rabbit_userid" /etc/ceilometer/ceilometer.conf
			os_region=$(grep -n "os_region_name" /etc/ceilometer/ceilometer.conf|cut -d ':' -f1)
			sed -i "${os_region}d" /etc/ceilometer/ceilometer.conf
			sed -i "${os_region}i$os_region_name" /etc/ceilometer/ceilometer.conf
		fi
	else
                echo "File: /etc/ceilometer/ceilometer.conf is not writable"
                echo "Please make ceilometer changes manually ....... "
        fi

	if [ -w /etc/neutron/neutron.conf ]
	then
		if [ $region_flag -eq 2 ]
                then
			neutron_region_entry="nova_region_name = SCL1"
			neutron_region=$(grep -n "nova_region_name" /etc/neutron/neutron.conf|cut -d ':' -f1)
			sed -i "${neutron_region}d" /etc/neutron/neutron.conf
			sed -i "${neutron_region}i$neutron_region_entry" /etc/neutron/neutron.conf
			neutron_rabbit_entry="rabbit_userid=expo_stack"			
			neutron_rabbit=$(grep -n "rabbit_userid=" /etc/neutron/neutron.conf|cut -d ':' -f1)
			sed -i "${neutron_rabbit}d" /etc/neutron/neutron.conf
			sed -i "${neutron_rabbit}i$neutron_rabbit_entry" /etc/neutron/neutron.conf		
		else
			if [ $region_flag -eq 1 ]
			then
				neutron_region_entry="nova_region_name = LA1"
                        	neutron_region=$(grep -n "nova_region_name" /etc/neutron/neutron.conf|cut -d ':' -f1)
                        	sed -i "${neutron_region}d" /etc/neutron/neutron.conf
                        	sed -i "${neutron_region}i$neutron_region_entry" /etc/neutron/neutron.conf
                        	neutron_rabbit_entry="rabbit_userid=expostack"
                        	neutron_rabbit=$(grep -n "rabbit_userid=" /etc/neutron/neutron.conf|cut -d ':' -f1)
                        	sed -i "${neutron_rabbit}d" /etc/neutron/neutron.conf
                        	sed -i "${neutron_rabbit}i$neutron_rabbit_entry" /etc/neutron/neutron.conf
			fi
		fi
	else
                echo "File: /etc/neutron/neutron.conf is not writable"
                echo "Please make ceilometer changes manually ....... "
	fi
		
	
	
	echo "Making Datcenter regional configuration changes .... "
	
	if [ -r /etc/nova/nova.conf ]
	then

		line=$(grep -n "dhcp_domain" /etc/nova/nova.conf |cut -d ':' -f1)

		sed -i "${line}d" /etc/nova/nova.conf

		if [ $region_flag -eq 1 ]
                then
			dhcp_domain="dhcp_domain = vpc.dev.la1.us.tribalfusion.net"
			rabbit_userid="rabbit_userid = expostack"
			line6=$(grep -n "expo_stack" /etc/nova/nova.conf|cut -d ':' -f1)
			sed -i "${line6}d" /etc/nova/nova.conf
			sed -i "${line6}i$rabbit_userid" /etc/nova/nova.conf
		fi

		if [ $region_flag -eq 2 ]
                then
			dhcp_domain="dhcp_domain = vpc.dev.scl1.us.tribalfusion.net"
                fi

		sed -i "${line}i$dhcp_domain" /etc/nova/nova.conf

		line2=$(grep -n "region_name" /etc/nova/nova.conf |cut -d ':' -f1)

		sed -i "${line2}d" /etc/nova/nova.conf

		if [ $region_flag -eq 1 ]
                then
			region_name="region_name = LA1"
                fi

                if [ $region_flag -eq 2 ]
                then
			region_name="region_name = SCL1"
                fi

		sed -i "${line2}i$region_name" /etc/nova/nova.conf

	else
		echo "File: /etc/nova/nova.conf is not readable"
		echo "Failed: Regional changes failed"
                echo "Exiting from script"
		exit 1
	fi

	if [ -r /etc/neutron/plugins/ml2/linuxbridge_agent.ini ]
	then
		line3=$(grep -n "linux_bridge" /etc/neutron/plugins/ml2/linuxbridge_agent.ini |cut -d ':' -f1)

		line3=$(( $line3 + 1 ))

		vlan="vlan"
		physical_interface_mappings="physical_interface_mappings = "
		entry="$physical_interface_mappings$network1:$vlan$vlanid1,$network2:$vlan$vlanid2"
		sed -i "${line3}i$entry" /etc/neutron/plugins/ml2/linuxbridge_agent.ini
	else
		echo "File: /etc/neutron/plugins/ml2/linuxbridge_agent.ini is not readble"
		echo "Failed: Regional changes failed"
                echo "Exiting from script"
		exit 1
	fi


	if [ -r /etc/neutron/plugins/ml2/ml2_conf.ini ]
        then
		line4=$(grep -n "linux_bridge" /etc/neutron/plugins/ml2/ml2_conf.ini|cut -d ':' -f1)

		line4=$(( $line4 + 1 ))

                vlan="vlan"
		physical_interface_mappings="physical_interface_mappings = "
                entry="$physical_interface_mappings$network1:$vlan$vlanid1,$network2:$vlan$vlanid2"
                sed -i "${line4}i$entry" /etc/neutron/plugins/ml2/ml2_conf.ini
        else
                echo "File: /etc/neutron/plugins/ml2/ml2_conf.ini is not readble"
		echo "Failed: Regional changes failed"
                echo "Exiting from script"
		exit 1
        fi

	if [ -r /var/lib/nova/instances/ceilometer/pipeline.yaml ]
        then
                line5=$(grep -n "resources" /var/lib/nova/instances/ceilometer/pipeline.yaml|cut -d ':' -f1)
                line5=$(( $line5 + 1 ))
                node_host=$(hostname)
                first="\ \ \ \ \ \ \ \ \ - snmp://public@"
                pipeline_yaml="$first$node_host"
                sed -i "${line5}i$pipeline_yaml" /var/lib/nova/instances/ceilometer/pipeline.yaml
        else
                echo "File: /var/lib/nova/instances/ceilometer/pipeline.yaml is not readble"
                echo "Failed: Regional changes failed"
                echo "Exiting from script"
                exit 1
        fi

	echo "Datacenter Regional configurational changes successful ... "
}

network_time_configuration () {

        echo "Taking backup of ntp.conf ...... "
        cp -p /etc/ntp.conf /etc/ntp.conf.file
        cp -p /etc/ntp.conf /etc/ntp.conf.bkp
        if [ $? -eq  0 ] 
	then
		exit_flag=0 
		echo "Backup of ntp made ... " 
		grep -v server /etc/ntp.conf > /etc/ntp.file 
		echo "Making following entries to ntp.conf ..." 
		echo "server 204.11.108.93" 
		echo "server 204.11.108.92" 
		echo "server 204.11.108.93" >> /etc/ntp.file 
		echo "server 204.11.108.92" >> /etc/ntp.file 
		rm -f /etc/ntp.conf 
		mv /etc/ntp.file /etc/ntp.conf  
	else
		echo "Failed: Backup of ntp failed .... "
		echo "Exiting from script ....." 
		exit_flag=1
	fi

	if [ $exit_flag -eq 1 ]
	then
		exit 1
	fi

	sudo /etc/init.d/ntp restart

	if [ $? -eq  0 ] 
	then
		exit_flag=0 
		echo "Service successfully restarted: ntp " 
	else	
		echo "Failed: Server restart failed - ntp " 
		echo "Please retry maually" 
		echo "Exiting from script ....." 
		exit_flag=1
	fi

	if [ $exit_flag -eq 1 ]
	then
		exit 1 
	fi
}

network_configuration () {

	echo "Compute will reboot now, Please make sure, you complete network configuration after reboot ......... "
	echo "After reboot, User can create instances under nova availability zone or user can add compute to any aggregate host ....... "
	echo "Rebooting ....... "

	#IP_Address=$(ifconfig|grep -e 'inet addr'|grep -v 127|cut -d ':' -f2|cut -d ' ' -f1)
	
	echo "address $IP_Address" >> /etc/network/interfaces

	sleep 30


}

restart_services () {

	echo "Restarting nova-api-metadata ...... "

	service nova-api-metadata restart

	if [ $? -eq  0 ] 
	then
		exit_flag=0 
		echo "Service successfully restarted: nova-api-metadata"
	else
		echo "Failed: Server restart failed - nova-api-metadata" 
		echo "Please retry maually" 
		echo "Exiting from script ....." 
		exit_flag=1 
	fi
	
	if [ $exit_flag -eq 1 ]
	then
		exit 1
 	fi
	
	echo "Restarting nova-compute ......... "
	service nova-compute restart
	if [ $? -eq  0 ] 
	then
		exit_flag=0 
		echo "Service successfully restarted: nova-compute " 
	else
		echo "Failed: Server restart failed - nova-compute " 
		echo "Please retry maually" 
		echo "Exiting from script ....." 
		exit_flag=1
	fi


	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi

	echo "Restarting nova-novncproxy .......... " 
	service nova-novncproxy restart
	if [ $? -eq  0 ] 
	then
		exit_flag=0
		echo "Service successfully restarted: nova-novncproxy " 
	else	
		echo "Failed: Server restart failed - nova-novncproxy "
		echo "Please retry maually"
		echo "Exiting from script ....." 
		exit_flag=1
	fi

	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi
	
#	echo "Restarting neutron-plugin-linuxbridge-agent ........ "
#	service neutron-plugin-linuxbridge-agent restart
#
#	if [ $? -eq  0 ] 
#	then
#		exit_flag=0
#		echo "Service successfully restarted: neutron-plugin-linuxbridge-agent " 
#	else
#		echo "Failed: Server restart failed - neutron-plugin-linuxbridge-agent " 
#		echo "Please retry maually" 
#		echo "Exiting from script ....." 
#		exit_flag=1 
#	fi
#
#	if [ $exit_flag -eq 1 ]
#	then 
#		exit 1
#	fi

	echo "Restarting libvirt-bin ........ "
	service libvirt-bin restart

	if [ $? -eq  0 ] 
	then
		exit_flag=0 
		echo "Service successfully restarted: libvirt-bin " 
	else
		echo "Failed: Server restart failed - libvirt-bin " 
		echo "Please retry maually" 
		echo "Exiting from script ....."
		exit_flag=1
	fi

	echo "Restarting ceilometer-agent-compute service ........ "
	restart ceilometer-agent-compute

        if [ $? -eq  0 ]
        then
                exit_flag=0
                echo "Service successfully restarted: ceilometer-agent-compute " 
        else
                echo "Failed: Server restart failed - ceilometer-agent-compute " 
                echo "Please retry maually" 
                echo "Exiting from script ....."
                exit_flag=1
        fi

	if [ $exit_flag -eq 1 ]
	then
		exit 1
	fi


	echo "Restarting snmpd service .......... "

	/etc/init.d/snmpd restart

	if [ $? -eq  0 ]
        then
                exit_flag=0
                echo "Service successfully restarted: snmpd "
        else
                echo "Failed: Server restart failed - snmpd "
                echo "Please retry maually"
                echo "Exiting from script ....."
                exit_flag=1
        fi

        if [ $exit_flag -eq 1 ]
        then
                exit 1
        fi

}


libvirtd_configurartion () {

        entry1='listen_tls = 0'
        entry2='listen_tcp = 1'
        entry3='auth_tcp = "none"'
        entry4='env libvirtd_opts="-d -l"'
        entry5='libvirtd_opts="-d -l"'

        echo "Taking backup of /etc/libvirt/libvirtd.conf ...... "
        cp -p /etc/libvirt/libvirtd.conf /etc/libvirt/libvirtd.conf.file
        cp -p /etc/libvirt/libvirtd.conf /etc/libvirt/libvirtd.conf.bkp

        if [ $? -eq 0 ] 
	then
		exit_flag=0 
		echo "Backup of libvirtd made .... " 
		cat /etc/libvirt/libvirtd.conf | grep -v listen_tls | grep -v listen_tcp | grep -v auth_tcp > /etc/libvirt/libvirtd.file 
		echo "Making following entries to libvirtd.conf ... " 
		echo $entry1 
		echo $entry2 
		echo $entry3 
		echo $entry1 >> /etc/libvirt/libvirtd.file 
		echo $entry2 >> /etc/libvirt/libvirtd.file 
		echo $entry3 >> /etc/libvirt/libvirtd.file 
		rm -f /etc/libvirt/libvirtd.conf 
		mv /etc/libvirt/libvirtd.file /etc/libvirt/libvirtd.conf 
	else
		echo "Failed: Backup of libvirtd failed .... " 
		echo "Exiting from script ....." 
		exit_flag=1 
	fi


	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi

        echo "Taking backup of /etc/init/libvirt-bin.conf ..... "
        cp -p /etc/init/libvirt-bin.conf /etc/init/libvirt-bin.conf.file
        cp -p /etc/init/libvirt-bin.conf /etc/init/libvirt-bin.conf.bkp

        if [ $? -eq 0 ] 
	then
		exit_flag=0 
		echo "Backup of libvirt-bin conf made .... " 
		cat /etc/init/libvirt-bin.conf | grep -v 'env libvirtd_opts' > /etc/init/libvirt-bin.conf.file 
		echo "Making following entries to libvirt-bin conf .... " 
		echo $entry4 
		sed -i "11i$entry4" /etc/init/libvirt-bin.conf.file
		rm -f /etc/init/libvirt-bin.conf 
		mv /etc/init/libvirt-bin.conf.file /etc/init/libvirt-bin.conf 
	else	
		echo "Failed: Backup of libvirt-bin failed .... " 
		echo "Exiting from script ....." 
		exit_flag=1
	fi

	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi

        echo "Taking backup of /etc/default/libvirt-bin ...... "
        cp -p /etc/default/libvirt-bin /etc/default/libvirt-bin.file
        cp -p /etc/default/libvirt-bin /etc/default/libvirt-bin.bkp

        if [ $? -eq 0 ] 
	then
		exit_flag=0 
		echo "Backup of libvirt-bin made .... " 
		cat /etc/default/libvirt-bin | grep -v libvirtd_opts > /etc/default/libvirt-bin.file 
		echo "Making following entries to libvirt-bin ......." 
		echo $entry5 
		echo $entry5 >> /etc/default/libvirt-bin.file 
		rm -f /etc/default/libvirt-bin 
		mv /etc/default/libvirt-bin.file /etc/default/libvirt-bin 
	else
		echo "Failed: Backup of libvirt-bin failed .... " 
		echo "Exiting from script ....." 
		exit_flag=1
	fi

	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi
}



configuration_files () {

	current_dir=$(pwd)

	if [ $compute_flag -eq 2 ]
	then
		mkdir /tmp/computeconf_allzone
		
		if [ $? -eq 0 ]
		then
			unzip $current_dir/computeconf_allzone.zip -d /tmp/computeconf_allzone/
			if [ $? -eq 0 ] 
			then
				exit_flag=0
				echo "Successfully defalted computeconf_allzone.zip at /tmp/computeconf_allzone" 
			else
				echo "Failed: Deflation of computeconf_allzone.zip failed" 
				echo "Exiting from script .... " 
				exit_flag=1
			fi
		

			if [ $exit_flag -eq 1 ]
			then
				exit 1
			fi

		else
			echo "Error: Could not create directory and deflate computeconf_allzone.zip"
			echo "Exiting from script ...... "
			exit_flag=1
			if [ $exit_flag -eq 1 ]
			then
				exit 1
			fi
		fi

		#For computeconf_allzone.zip: 
	
		#Step 1:  There are two folders nova and neutron, move both the folders in /etc 

 		#A: Copy /computeconf_allzone/computeconf/neutron to /etc/ of compute-node you are building.

		cp -avr /tmp/computeconf_allzone/computeconf/neutron /etc

		if [ $? -eq 0 ]
		then
			exit_flag=0 
			echo "Created Neutron configuration files" 
		else
			echo "Failed: Neutron configuration failed" 
			echo "Exiting from script ...." 
			exit_flag=1
		fi

		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi
		
		#B: Copy /computeconf_allzone/computeconf/nova to /etc/ of compute-node you are building.

		cp -avr /tmp/computeconf_allzone/computeconf/nova /etc

		if [ $? -eq 0 ] 
		then
			exit_flag=0 
			echo "Created Nova configuration files" 
		else
			echo "Failed: Nova configuration failed" 
			echo "Exiting from script ...." 
			exit_flag=1
		fi
	
		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi

		#Step 2: copy all files in /etc/init/*neutron*.conf from attached file  to /etc/init/ of compute-node you are building

		#A:copy /computeconf_allzone/computeconf/neutron/neutron.conf  to  /etc/init/ of compute-node you are building

		cp -p /tmp/computeconf_allzone/computeconf/neutron/neutron.conf /etc/init/

		if [ $? -eq 0 ] 
		then
			exit_flag=0 
			echo "Configured neutron" 
		else
			echo "Failed: Neutron configuration failed" 
			echo "Exiting from script ...." 
			exit_flag=1
		fi

		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi

		#Step 3: /computeconf_allzone/computeinit has following files, where to copy these :

		#A: Copy /computeconf_allzone/computeinit to /etc/init/ 
		
		cp -avr /tmp/computeconf_allzone/computeinit/* /etc/init/

		if [ $? -eq 0 ] 
		then
			exit_flag=0 
			echo "Copied init files to /etc/init"
		else
			echo "Failed: Failed to copy init files to /etc/init" 
			echo "Exiting from script ...." 
			exit_flag=1
		fi

		cp -p /tmp/computeconf_allzone/neutron-plugin-linuxbridge-agent.conf /etc/init/neutron-plugin-linuxbridge-agent.conf 
		
		if [ $? -eq 0 ]
                then
                        exit_flag=0
                        echo "Neutron configuration file copied"
                else
                        echo "Failed: Neutron configuration file copy unsuccessful" 
                        echo "Exiting from script ...." 
                        exit_flag=1
                fi

		
		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi

		rm -rf /tmp/computeconf_allzone

	fi

	if [ $compute_flag -eq 1 ]
	then
		mkdir /tmp/computeconf_solzone

		if [ $? -eq 0 ]
                then
                        unzip $current_dir/computeconf_solzone.zip -d /tmp/computeconf_solzone/
                        if [ $? -eq 0 ] 
			then
				exit_flag=0 
				echo "Successfully defalted computeconf_allzone.zip at /tmp/computeconf_solzone"
			else
				echo "Failed: Deflation of computeconf_solzone.zip failed" 
				echo "Exiting from script .... " 
				exit_flag=1
			fi

			if [ $exit_flag -eq 1 ]
			then
				exit 1
			fi

                else
                        echo "Error: Could not create directory and deflate computeconf_solzone.zip"
                        echo "Exiting from script ...... "
                        exit_flag=1

			if [ $exit_flag -eq 1 ]
			then
				exit 1
			fi
                fi

		#For computeconf_solzone.zip: 

		#Step 1:  There are two folders nova and neutron ,move both the folders in /etc

		#A: Copy /computeconf_solzone/computeconf/neutron to /etc/ of compute-node you are building.

		cp -avr /tmp/computeconf_solzone/computeconf/neutron /etc

		if [ $? -eq 0 ] 
		then
			exit_flag=0 
			echo "Created Neutron configuration files"
		else
			echo "Failed: Neutron configuration failed" 
			echo "Exiting from script ...." 
			exit_flag=1 
		fi



		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi

		#B: Copy /computeconf_solzone/computeconf/nova to /etc/ of compute-node you are building.

		cp -avr /tmp/computeconf_solzone/computeconf/nova /etc

		if [ $? -eq 0 ] 
		then
			exit_flag=0 
			echo "Created Nova configuration files" 
		else
			echo "Failed: Nova configuration failed" 
			echo "Exiting from script ...." 
			exit_flag=1
		fi

		if [ $exit_flag -eq 1 ]
		then 
			exit 1
		fi

		#Step 2: copy all files in /etc/init/*neutron*.conf from attached file  to /etc/init/ of compute-node you are building

		#A: copy /computeconf_solzone/computeconf/neutron  to  /etc/init/ of compute-node you are building

		cp -p /tmp/computeconf_solzone/computeconf/neutron/neutron.conf /etc/init/

                if [ $? -eq 0 ] 
		then
			exit_flag=0 
			echo "Configured neutron" 
		else
			echo "Failed: Neutron configuration failed" 
			echo "Exiting from script ...." 
			exit_flag=1
		fi


		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi

		#Step 3: Copy computeconf_solzone/computeinit to /etc/init/

		#A: My Undertanding: Copy /computeconf_solzone/computeinit to /etc/init/ 

		cp -avr /tmp/computeconf_solzone/computeinit/* /etc/init/

                if [ $? -eq 0 ] 
		then
			exit_flag=0 
			echo "Copied init files to /etc/init" 
		else
			echo "Failed: Failed to copy init files to /etc/init" 
			echo "Exiting from script ...." 
			exit_flag=1
		fi

		cp -p /tmp/computeconf_solzone/neutron-plugin-linuxbridge-agent.conf /etc/init/neutron-plugin-linuxbridge-agent.conf

                if [ $? -eq 0 ]
                then
                        exit_flag=0
                        echo "Neutron configuration file copied"
                else
                        echo "Failed: Neutron configuration file copy unsuccessful" 
                        echo "Exiting from script ...." 
                        exit_flag=1
                fi



		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi

                rm -rf /tmp/computeconf_solzone

	fi

	

}


configuration_IP_Change () {


	#IP_Address=$(ifconfig|grep -e 'inet addr'|grep -v 127|cut -d ':' -f2|cut -d ' ' -f1)

	if [ $compute_flag -eq 1 ]
        then
		#For Sol Zone: #10.28.4.16
		#/etc/nova/nova.conf

                sed -i "s/10.28.4.16/$IP_Address/g" /etc/nova/nova.conf
                if [ $? -eq 0 ] 
		then
			exit_flag=0
			echo "Nova configured to IP Address: $IP_Address"
		else
			echo "Failed: Nova configured to IP Address $IP_Address failed." 
			echo "Exiting from script ..... " 
			exit_flag=1
		fi

		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi
	fi


	if [ $compute_flag -eq 2 ]
        then
		#For All Zone: #10.28.4.13
		#/etc/nova/nova.conf

		sed -i "s/10.28.4.13/$IP_Address/g" /etc/nova/nova.conf	

		if [ $? -eq 0 ] 
		then
			exit_flag=0 
			echo "Nova configured to IP Address: $IP_Address"
		else
			echo "Failed: Nova configured to IP Address $IP_Address failed." 
			echo "Exiting from script ..... " 
			exit_flag=1
		fi

		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi
	fi


}


admin_permission () {

        if [ -f /etc/sudoers ]
        then
                echo "Adding Permissions to allow password less sudo to administrator user"
                echo "administrator ALL=(root) NOPASSWD:ALL" >> /etc/sudoers
		exit_flag=0 
        else
                echo "/etc/sudoers file not found"
                echo "Exiting from script ..... "
                exit_flag=1
		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi
        fi

}

dns_servers () {


	echo "Verifying DNS server entries ........ "

	if [ $region_flag -eq 1 ]
        then
		name_server1=$(cat /etc/resolv.conf|grep 10.30.10.197)
		if [ -z "$name_server1" ]
		then
			echo "DNS entry not found for 10.30.10.197"
                        echo "Making DNS entry for 10.30.10.197 ....... "
                        echo "nameserver 10.30.10.197" >> /etc/resolv.conf
                        if [ $? -eq 0 ]
                        then
                                echo "DNS entry made .... "
                        else
                                echo "DNS entry failed ....... "
                                echo "Please check manually .... "
                                echo "Exiting from script ...... "
                                exit 1
                        fi
		else
                	echo $name_server1|grep "#"
                	if [ $? -eq 0 ]
                	then
				echo "DNS entry not found for 10.30.10.197"
				echo "Making DNS entry for 10.30.10.197 ....... "
                        	echo "nameserver 10.30.10.197" >> /etc/resolv.conf
				if [ $? -eq 0 ]
				then
					echo "DNS entry made .... "
				else
					echo "DNS entry failed ....... "
					echo "Please check manually .... "
					echo "Exiting from script ...... "
					exit 1
				fi
			else
				echo "DNS entry found for 10.30.10.197"
                	fi
		fi

                name_server2=$(cat /etc/resolv.conf|grep 10.30.10.198)
		if [ -z "$name_server2" ]
		then
			echo "DNS entry not found for 10.30.10.198"
                        echo "Making DNS entry for 10.30.10.198"
                        echo "nameserver 10.30.10.198" >> /etc/resolv.conf

                        if [ $? -eq 0 ]
                        then
                                echo "DNS entry made .... "
                        else
                                echo "DNS entry failed ....... "
                                echo "Please check manually .... "
                                echo "Exiting from script ...... "
                                exit 1
                        fi
		else
                	echo $name_server2|grep "#"
                	if [ $? -eq 0 ]
                	then
				echo "DNS entry not found for 10.30.10.198"
				echo "Making DNS entry for 10.30.10.198"
                        	echo "nameserver 10.30.10.198" >> /etc/resolv.conf
				
				if [ $? -eq 0 ]
                        	then
                                	echo "DNS entry made .... "
                        	else
                                	echo "DNS entry failed ....... "
                                	echo "Please check manually .... "
                                	echo "Exiting from script ...... "
                                	exit 1
                        	fi
			else
				echo "DNS entry found for 10.30.10.198"
			fi
		fi

        fi

        if [ $region_flag -eq 2 ]
        then
		name_server1=$(cat /etc/resolv.conf|grep 204.11.108.93)
		
		if [ -z $name_server1 ]
		then
			echo "DNS entry not found for 204.11.108.93"
                        echo "Making DNS entry for 204.11.108.93"
                        echo "nameserver 204.11.108.93" >> /etc/resolv.conf

                        if [ $? -eq 0 ]
                        then
                                echo "DNS entry made .... "
                        else
                                echo "DNS entry failed ....... "
                                echo "Please check manually .... "
                                echo "Exiting from script ...... "
                                exit 1
                        fi
		else	
			echo $name_server1|grep "#"
			if [ $? -eq 0 ]
			then
				echo "DNS entry not found for 204.11.108.93"
				echo "Making DNS entry for 204.11.108.93"
				echo "nameserver 204.11.108.93" >> /etc/resolv.conf
			
				if [ $? -eq 0 ]
                        	then
                                	echo "DNS entry made .... "
                        	else
                                	echo "DNS entry failed ....... "
                                	echo "Please check manually .... "
                                	echo "Exiting from script ...... "
                                	exit 1
                        	fi
			else
                                echo "DNS entry found for 204.11.108.93"
                        fi
				
		fi

		name_server2=$(cat /etc/resolv.conf|grep 204.11.108.92)
		if [ -z $name_server2 ]
		then
			echo "DNS entry not found for 204.11.108.92"
                        echo "Making DNS entry for 204.11.108.92"
                        echo "nameserver 204.11.108.92" >> /etc/resolv.conf
		
			if [ $? -eq 0 ]
                        then
                                echo "DNS entry made .... "
                        else
                                echo "DNS entry failed ....... "
                                echo "Please check manually .... "
                                echo "Exiting from script ...... "
                                exit 1
                        fi
		else
			echo $name_server2|grep "#"		
			if [ $? -eq 0 ]
                	then
				echo "DNS entry not found for 204.11.108.92"
				echo "Making DNS entry for 204.11.108.92"
				echo "nameserver 204.11.108.92" >> /etc/resolv.conf
			
				if [ $? -eq 0 ]
                        	then
                                	echo "DNS entry made .... "
                        	else
                                	echo "DNS entry failed ....... "
                                	echo "Please check manually .... "
                                	echo "Exiting from script ...... "
                                	exit 1
                        	fi
			else
				echo "DNS entry found for 204.11.108.92"
			fi	
		fi		
        fi

}

mount_compute () {

	if [ $region_flag -eq 2 ]
	then
		#echo "Mounting filer30:/vol/openstack_compute_01 as /var/lib/nova/instances"
		echo "Mounting svm-dev-01-504-lif:/expo_openstack_compute_01 as /var/lib/nova/instances"
	fi

	if [ $region_flag -eq 1 ]
	then 
		echo "Mounting svm-dr-01-110-lif:/openstack_lacompute_01 as  /var/lib/nova/instances"
	fi

        echo "Taking a backup of fstab file ......"
        cp -p /etc/fstab /etc/fstab.bkp.$(date +%F_%R)
        if [ $? -eq  0 ] 
	then
		exit_flag=0
		echo "Backup of fstab made ..."
	else
		echo "Failed: Backup of fstab failed .... "
		echo "Exiting from script ....."
		exit_flag=1 
	fi
	
	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi

       	echo "Preparing a mount point: /var/lib/nova/instances"
	if [ -e /var/lib/nova/instances ]
	then
		echo " "
	else
       		mkdir -p /var/lib/nova/instances
		chmod 777 /var/lib/nova/instances
	fi	


       	if [ $? -eq  0 ]
	then
		exit_flag=0
		echo "Mount point prepared: /var/lib/nova/instances"
	else
		echo "Mount point failed: /var/lib/nova/instances" 
		echo "exiting from script ..."
		exit_flag=1
	fi


	if [ $exit_flag -eq 1 ]
	then
		exit 1
	fi

	if [ $region_flag -eq 1 ]
        then
		mount svm-dr-01-110-lif:/openstack_lacompute_01 /var/lib/nova/instances
		if [ $? -eq  0 ]
                then
                        exit_flag=0

                        echo "Successfully mounted svm-dr-01-110-lif:/openstack_compute_01 as /var/lib/nova/instances"

                        echo "svm-dr-01-110-lif:/openstack_lacompute_01       /var/lib/nova/instances nfs     vers=3  0 0" >> /etc/fstab

                        if [ $? -eq 0 ]
                        then
                                echo "Made following entry in fstab: "
                                echo "svm-dr-01-110-lif:/openstack_lacompute_01       /var/lib/nova/instances nfs     vers=3  0 0"
                                exit_flag=0
                        else
                                echo "Failed to make following entry in fstab"
                                echo "svm-dr-01-110-lif:/openstack_lacompute_01       /var/lib/nova/instances nfs     vers=3  0 0"
                                exit_flag=1
                        fi

                elif [ $(mount -v |grep -w /var/lib/nova/instances|wc -l) -eq 1 ]
                then
                        echo "Filesystem /var/lib/nova/instances is already mounted"
                        exit_flag=0
                else
                        echo "Mount Failed: Mount of svm-dr-01-110-lif:/openstack_compute_01 as /var/lib/nova/instances failed"
                        echo "Exiting from script ....."
                        exit_flag=1
                fi
        fi

	if [ $region_flag -eq 2 ]
        then
		#mount filer30:/vol/openstack_compute_01 /var/lib/nova/instances
		mount svm-dev-01-504-lif:/expo_openstack_compute_01 /var/lib/nova/instances
		if [ $? -eq  0 ]
        	then
                	exit_flag=0

                	#echo "Successfully mounted filer30:/vol/openstack_compute_01 as /var/lib/nova/instances"
			echo "Successfully mounted svm-dev-01-504-lif:/expo_openstack_compute_01 as /var/lib/nova/instances"

                	#echo "filer30:/vol/openstack_compute_01       /var/lib/nova/instances nfs     vers=3  0 0" >> /etc/fstab
			echo "svm-dev-01-504-lif:/expo_openstack_compute_01       /var/lib/nova/instances nfs     vers=3  0 0" >> /etc/fstab

                	if [ $? -eq 0 ]
                	then
                        	echo "Made following entry in fstab: "
                        	#echo "filer30:/vol/openstack_compute_01       /var/lib/nova/instances nfs     vers=3  0 0"
				echo "svm-dev-01-504-lif:/expo_openstack_compute_01       /var/lib/nova/instances nfs     vers=3  0 0"
                        	exit_flag=0
                	else
                        	echo "Failed to make following entry in fstab"
                        	#echo "filer30:/vol/openstack_compute_01       /var/lib/nova/instances nfs     vers=3  0 0"
				echo "svm-dev-01-504-lif:/expo_openstack_compute_01       /var/lib/nova/instances nfs     vers=3  0 0"
                        	exit_flag=1
                	fi
        	elif [ $(mount -v |grep -w /var/lib/nova/instances|wc -l) -eq 1 ]
        	then
               		echo "Filesystem /var/lib/nova/instances is already mounted"
               		exit_flag=0
        	else
               		#echo "Mount Failed: Mount of filer30:/vol/openstack_compute_01 as /var/lib/nova/instances failed"
			echo "Mount Failed: Mount of svm-dev-01-504-lif:/expo_openstack_compute_01 as /var/lib/nova/instances failed"
               		echo "Exiting from script ....."
               		exit_flag=1
        	fi
        fi

	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi

}

migration_enable () {

	if [ -f /etc/libvirt/libvirtd.conf ] 
	then
		exit_flag=0
		echo "File: /etc/libvirt/libvirtd.conf exists .... "
		echo "Making following entries to file .... "
		echo "listen_tls = 0"
		echo "listen_tcp = 1"
		echo 'auth_tcp = "none"'
		echo "listen_tls = 0" >> /etc/libvirt/libvirtd.conf
		echo "listen_tcp = 1" >> /etc/libvirt/libvirtd.conf
		echo 'auth_tcp = "none"' >> /etc/libvirt/libvirtd.conf
	else
		echo "File: /etc/libvirt/libvirtd.conf does not exists .... "
		echo "exiting from script ..."
		exit_flag=1
	fi


	if [ $exit_flag -eq 1 ]
	then
 		exit 1
	fi

	if [ -f /etc/init/libvirt-bin.conf ]
	then
		exit_flag=0
		echo "File: /etc/init/libvirt-bin.conf exists .... "
		echo "Making following entries to file .... "
		echo 'env libvirtd_opts="-d -l"'
		echo 'env libvirtd_opts="-d -l"' >> /etc/init/libvirt-bin.conf 
	else
		echo "File: /etc/init/libvirt-bin.conf does not exists .... "
		echo "exiting from script ..."
		exit_flag=1
	fi


	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi

	if [ -f /etc/default/libvirt-bin ]
	then
		exit_flag=0 
		echo "File: /etc/default/libvirt-bin exists .... " 
		echo "Making following entries to file .... " 
		echo 'libvirtd_opts="-d -l"' 
		echo 'libvirtd_opts="-d -l"' >> /etc/default/libvirt-bin
	else
		echo "File: /etc/default/libvirt-bin does not exists .... "
		echo "exiting from script ..."
		exit_flag=1
	fi

	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi


}

destroy_virtual_bridge () {


	virsh net-list	

	sudo virsh net-destroy default

	if [ $? -eq 0 ] 
	then
 		exit_flag=0
		echo "Virtual bridge destroyed"
	else
		echo "Failed: Virtual bridge destroy failed"
		echo "Please try manually ..... "
	fi


	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi

	sudo virsh net-undefine default

	if [ $? -eq 0 ]
	then
		exit_flag=0
		echo "Virtual bridge destroyed"
	else
		echo "Failed: Virtual bridge destroy failed"
		echo "Please try manually ..... "
	fi

	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi


}

change_ip_controller () {

	#IP_Address=$(ifconfig|grep -e 'inet addr'|grep -v 127|cut -d ':' -f2|cut -d ' ' -f1)
	
	files=$(grep /etc -rnl -e 10.28.4.12)

	if [ -z $file ]
	then
		echo "Change IP Controller function - Files: $file found to be empty"
		echo "This is a fatal error, please check manually .... "
		echo "Exiting from script ..... "
		exit_flag=1
	fi

	grep /etc -rnl -e 10.28.4.12 | xargs sed -i "s/10.28.4.12/$IP_Address/g"

	if [ $? -eq 0 ]
	then
		exit_flag=0 
		echo "IP Address change from 10.28.4.12 to $IP_Address in the following files: $files was successful"
	else
		echo "IP Address change from 10.28.4.12 to $IP_Address in the following files: $files was not successful"
		echo "Please make changes manually"
		echo "Exiting from script ......"
		exit_flag=1
	fi

	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi

}

change_hosts_controller () {

	if [ -f /etc/hosts ]
	then
		exit_flag=0
		cp -p /etc/hosts /etc/hosts.file
		cp -p /etc/hosts /etc/hosts.bkp
		cat /etc/hosts | grep -v controller > /etc/hosts.file
		echo "File: /etc/hosts exists, adding controller to it"
		if [ $region_flag -eq 1 ]
		then
			echo "10.24.4.11 controller" >> /etc/hosts.file
		fi
		
		if [ $region_flag -eq 2 ]
                then
			echo "10.29.16.60 controller" >> /etc/hosts.file 
			#echo "10.29.16.62 controller" >> /etc/hosts.file
		fi

		rm -f /etc/hosts
		mv /etc/hosts.file /etc/hosts
	else
		echo "File: /etc/hosts doesn't exist"
		echo "Exiting from script ..... "
		exit_flag=1
	fi

	if [ $exit_flag -eq 1 ]
	then 
		exit 1
	fi

}

configure_VLAN () {

	entry1_Flag=0
	entry2_Flag=0
	entry3_Flag=0
        entry4_Flag=0
	entry5_Flag=0
        entry6_Flag=0
        entry7_Flag=0
        entry8_Flag=0
	entry9_Flag=0
	entry10_Flag=0
	vlan="vlan"


	if [ -w /etc/network/interfaces ]
	then
		exit_flag=0
		if [ -e /etc/network/interfaces_compute_script_org ]
                then
			echo "Taking backup of existing configuration"
			cp -p /etc/network/interfaces_compute_script_org /etc/network/interfaces
		else
			echo "Taking backup of network configurations... "
			cp -p /etc/network/interfaces /etc/network/interfaces_compute_script_org
                fi

		echo "Configuring network interface ....... "
		echo "Making entries of following interfaces as auto ...... "

                interfaces=$(ls /sys/class/net)
                echo $interfaces

                #for i in $interfaces:
                #do
		#	j=$(echo $i|cut -d ":" -f1)
                #        echo "auto $j" >> /var/tmp/compute-nova-build/file.test
                #done
		
		echo "Making following entries at network interfaces ..... "
	
		#cat /etc/network/interfaces | grep 'auto $interface'

		#if [ $? -eq 0 ]
		#then
		#	echo " "
		#else
			echo "auto $interface"
		#	echo "auto $interface" >> /etc/network/interfaces
		#	if [ $? -eq 0 ]
		#	then
		#		entry1_Flag=1
		#	fi
		#fi

		#cat /etc/network/interfaces | grep 'iface $interface inet static'		

		#if [ $? -eq 0 ]
                #then
                #        echo " "
                #else    
                        echo "iface $interface inet static"
		#	echo "iface $interface inet static" >> /etc/network/interfaces
		#	if [ $? -eq 0 ]
		#	then
                #        	entry2_Flag=1
		#	fi
                #fi

		#cat /etc/network/interfaces | grep 'auto vlan2048'

		#if [ $? -eq 0 ]
                #then
                #        echo " "
                #else
                        echo "auto $vlan$vlanid2" #"vlan2048"
		#	echo "auto vlan2048" >> /etc/network/interfaces
		#	if [ $? -eq 0 ]
		#	then
		#		entry3_Flag=1
		#	fi
                #fi

		#cat /etc/network/interfaces | grep 'iface vlan2048 inet static'
		
		#if [ $? -eq 0 ]
                #then
                #        echo " "
                #else
                        echo "iface $vlan$vlanid2 inet static" #"vlan2048 inet static"
		#	echo "iface vlan2048 inet static" >> /etc/network/interfaces
		#	if [ $? -eq 0 ]
		#	then
                #        	entry4_Flag=1
		#	fi
                #fi

		#cat /etc/network/interfaces | grep 'address 0.0.0.0'
		
		#if [ $? -eq 0 ]
		#then
		#	echo " "
                #else
                        echo "address 0.0.0.0"
		#	echo "address 0.0.0.0" >> /etc/network/interfaces
                #        if [ $? -eq 0 ]
                #        then
                #                entry5_Flag=1
                #        fi
                #fi 

	 
		echo "vlan-raw-device $interface"
		echo "auto $vlan$vlanid1" #"vlan132"
		echo "iface $vlan$vlanid1 inet static" #"vlan132 inet static"
		echo "address 0.0.0.0"
		echo "vlan-raw-device $interface"



		sleep 3
		
		
		echo "auto $interface" >> /etc/network/interfaces
		if [ $? -eq 0 ]
		then
			entry1_Flag=1
		fi
	
		echo "iface $interface inet static" >> /etc/network/interfaces
		if [ $? -eq 0 ]
                then
                        entry2_Flag=1
		fi

		echo "auto $vlan$vlanid2" >> /etc/network/interfaces #vlan2048
                if [ $? -eq 0 ]
                then
                        entry3_Flag=1
                fi

		echo "iface $vlan$vlanid2 inet static" >> /etc/network/interfaces #vlan2048
                if [ $? -eq 0 ]
                then
                        entry4_Flag=1
                fi

		echo "address 0.0.0.0" >> /etc/network/interfaces
                if [ $? -eq 0 ]
                then 
                        entry5_Flag=1
                fi 

		echo "vlan-raw-device $interface" >> /etc/network/interfaces
                if [ $? -eq 0 ]
                then
                        entry9_Flag=1
                fi

		echo "auto $vlan$vlanid1" >> /etc/network/interfaces #"vlan132"
                if [ $? -eq 0 ]
                then 
                        entry6_Flag=1
                fi

		echo "iface $vlan$vlanid1 inet static" >> /etc/network/interfaces #vlan132
                if [ $? -eq 0 ]
                then 
                        entry7_Flag=1
                fi

		echo "address 0.0.0.0" >> /etc/network/interfaces
                if [ $? -eq 0 ]
                then 
                        entry8_Flag=1
                fi

		echo "vlan-raw-device $interface" >> /etc/network/interfaces
                if [ $? -eq 0 ]
                then
                        entry10_Flag=1
                fi
			
	
		if [ $entry1_Flag -eq 1 ] && [ $entry2_Flag -eq 1 ] && [ $entry3_Flag -eq 1 ] && [ $entry4_Flag -eq 1 ] && [ $entry5_Flag -eq 1 ] && [ $entry6_Flag -eq 1 ] && [ $entry7_Flag -eq 1 ] && [ $entry8_Flag -eq 1 ] && [ $entry9_Flag -eq 1 ] && [ $entry10_Flag -eq 1 ]
		then
			echo "Successfully configured network interface ..... "
		else
			echo "Failed: Network interface configuration failed. "
			echo "Exiting from script ..... "
			exit 1
		fi		
	
	else
		echo "Failed: Network interface configuration failed. "
		exit_flag=1		

	fi
	
	if [ $exit_flag -eq 1 ]
        then
                exit 1
        fi

}


configure_nova_distribution_package () {

#	if [ -e /usr/lib/python2.7/dist-packages/nova ]
 	if [ -e /usr/lib/python2.7/dist-packages/ ]
	then
		if [ -e /usr/lib/python2.7/dist-packages/nova_org ]
		then
			unlink /usr/lib/python2.7/dist-packages/nova
		else
			mv /usr/lib/python2.7/dist-packages/nova /usr/lib/python2.7/dist-packages/nova_org
		fi

#		if [ $? -eq 0 ]
#		then
#			echo "Success: Configured Nova distribution package."
#			exit_flag=0
#		else
#			echo "Failed: Failed to configure Nova distribution package."
#			exit_flag=1
#		fi
	
		if [ -e /usr/lib/python2.7/dist-packages/ ]
		then
			cd  /usr/lib/python2.7/dist-packages/
			if [ $? -eq 0 ]
			then
				if [ -L nova ] && [ "$(readlink nova)" == "/var/lib/nova/instances/nova/" ]
				then 
					echo "Symbolic link exists: nova is a link to /var/lib/nova/instances/nova/"
				else 
					ln -s /var/lib/nova/instances/nova/ .
					if [ $? -eq 0 ]
					then
						echo "Success: Configured Nova distribution package."
						echo "Symbolic link created: nova to /var/lib/nova/instances/nova/"
					else
						echo "Failed: Failed to configure Nova distribution package."
                        			exit_flag=1 
					fi
				fi
			else
				
				echo "Failed: Failed to configure Nova distribution package."
                                exit_flag=1
			fi
			cd -
		else
			echo "Failed: Failed to configure Nova distribution package."
                        exit_flag=1
		fi

	else
#		if [ -e /usr/lib/python2.7/dist-packages/nova_org ]
#		then
#			echo "Success: Configured Nova distribution package."
#			exit_flag=0
#		else
			echo "Failed: Failed to configure Nova distribution package."
                	exit_flag=1
#		fi

	fi


	if [ $exit_flag -eq 1 ]
       	then
               	exit 1
       	fi

}
	

qemu_configuration () {

entry1='cgroup_device_acl = ['
entry2='    "/dev/null", "/dev/full", "/dev/zero",'
entry3='    "/dev/random", "/dev/urandom",'
entry4='    "/dev/ptmx", "/dev/kvm", "/dev/kqemu",'
entry5='    "/dev/rtc","/dev/hpet", "/dev/vfio/vfio"'
entry6=']'

entry7='security_driver = "none"'

entry8='user = "root"'

entry9='group = "root"'

entry10='cgroup_controllers = [ "cpu", "devices", "memory", "blkio", "cpuset", "cpuacct" ]'

entry11='clear_emulator_capabilities = 0'

if [ -f /etc/libvirt/qemu.conf ]
then
	exit_flag=0 
	echo "File: /etc/libvirt/qemu.conf exists "
	echo " "

	cat /etc/libvirt/qemu.conf | grep '#' > /etc/libvirt/qemu.conf.bkp
	if [ $? -eq 0 ]
	then
		echo "Copy of qemu configuration made: "
        	echo " "
        	echo "Making following entries ...... "
        	echo " "
        	echo "$entry1"
        	echo "$entry2"
        	echo "$entry3"
        	echo "$entry4"
        	echo "$entry5"
        	echo "$entry6"
        	echo  " "
        	echo -e "$entry7 \n"
        	echo " "
        	echo -e "$entry8 \n"
	        echo " "
       	 	echo -e "$entry9 \n"
        	echo  " "
        	echo -e "$entry10 \n"
        	echo " "
        	echo -e "$entry11 \n"

 		echo $entry1 >> /etc/libvirt/qemu.conf.bkp
        	echo $entry2 >> /etc/libvirt/qemu.conf.bkp
        	echo $entry3 >> /etc/libvirt/qemu.conf.bkp
        	echo $entry4 >> /etc/libvirt/qemu.conf.bkp
        	echo $entry5 >> /etc/libvirt/qemu.conf.bkp
        	echo $entry6 >> /etc/libvirt/qemu.conf.bkp
		echo $entry7 >> /etc/libvirt/qemu.conf.bkp
		echo $entry8 >> /etc/libvirt/qemu.conf.bkp
		echo $entry9 >> /etc/libvirt/qemu.conf.bkp
        	echo $entry10 >> /etc/libvirt/qemu.conf.bkp
		echo $entry11 >> /etc/libvirt/qemu.conf.bkp
	else
		echo "Failed: Copy of qemu configuration unsuccessful"
		echo "Exiting from script ...... "
		exit_flag=1
	fi

else
	echo "File: /etc/libvirt/qemu.conf doesn't exists ... " 
	echo "Please check and make entries manually ... "
	echo "Exiting from script ...... "
	exit_flag=1
fi


mv /etc/libvirt/qemu.conf.bkp /etc/libvirt/qemu.conf

if [ $? -eq 0 ]
then
	echo "qemu configuration successfully completed"
else
	echo "Failed: qemu configuration failed"
	echo "Exiting from script ...... "
	exit_flag=1
fi

if [ $exit_flag -eq 1 ]
then 
	exit 1
fi

}

kvm_compliance () {

        echo "Testing KVM compliance ....."
        sudo modprobe kvm_intel
	kvm-ok

        if [ $? -eq 0 ] 
	then
	 	exit_flag=0 
		echo "======================================================================================================" 
		echo "This machine is KVM compliant ............." 
		echo "======================================================================================================" 
	else
	 	echo "########################## This machine is not KVM compliant, Please make sure BIOS virtulization switch is enabled and try again  ##############################################" 
		echo "Exiting from script ................"  
		exit_flag=1 
	fi

	if [ $exit_flag -eq 1 ]
	then 
		exit 1
 	fi

}

apt_configuration () {

flag1=0;flag2=0;flag3=0;flag4=0;

echo " "

echo  " "

cat /etc/apt/apt.conf|grep 'Acquire::http::proxy "http://proxy-02:3128";'

if [ $? -ne 0 ]
then
	echo 'Acquire::http::proxy "http://proxy-02:3128"'
	echo 'Acquire::http::proxy "http://proxy-02:3128";' >> /etc/apt/apt.conf
	if [ $? -eq 0 ]
	then
        	flag1=1;
	fi
else
		flag1=1;	
fi

cat /etc/apt/apt.conf|grep 'Acquire::https::proxy "https://proxy-02:3128";'

if [ $? -ne 0 ]
then
	echo 'Acquire::https::proxy "https://proxy-02:3128";'
	echo 'Acquire::https::proxy "https://proxy-02:3128";' >> /etc/apt/apt.conf
	if [ $? -eq 0 ]
	then
        	flag2=1;
	fi
else
		flag2=1;
fi

cat /etc/apt/apt.conf|grep 'Acquire::http::proxy "http://204.11.108.89:3128";'

if [ $? -ne 0 ]
then
	echo 'Acquire::http::proxy "http://204.11.108.89:3128"'
	echo 'Acquire::http::proxy "http://204.11.108.89:3128";' >> /etc/apt/apt.conf
	if [ $? -eq 0 ]
	then
        	flag3=1;
	fi
else
	flag3=1;
fi

cat /etc/apt/apt.conf|grep 'Acquire::https::proxy "https://204.11.108.89:3128";'

if [ $? -ne 0 ]
then
	echo 'Acquire::https::proxy "https://204.11.108.89:3128"'
	echo 'Acquire::https::proxy "https://204.11.108.89:3128";' >> /etc/apt/apt.conf
	if [ $? -eq 0 ]
	then
        	flag4=1;
	fi
else
	flag4=1;
fi

if [ $flag1 -eq 1 ] && [ $flag2 -eq 1 ] && [ $flag3 -eq 1 ] && [ $flag4 -eq 1 ]
then
        echo " "
        echo 'All entries made to made to file /etc/apt/apt.conf'
	exit_flag=0 
else
        echo  " "
        echo "All entries were not made to file /etc/apt/apt.conf"
        echo "Please manually verify file and make above mentioned entries ..... "
        echo "Exiting script ......... "
        exit_flag=1
	if [ $exit_flag -eq 1 ]
	then
		exit 1
	fi
fi



}

apt_proxy_changes () {


		if [ -f /etc/apt/apt.conf ]
        	then
			echo "/etc/apt/apt.conf file exists, making following entries ..... "
			apt_configuration
		else
			echo "/etc/apt/apt.conf file doesn't exist ..... "
			touch /etc/apt/apt.conf
			if  [ $? -eq 0 ]
			then
				echo "Created /etc/apt/apt.conf file"
				echo "Making changes to apt configuration"
				apt_configuration
	
			fi
		fi



}

start () {
	
	clear

	false () {

        	echo -e "\nIllegal parameter"
        	echo -e '\n\nFor usage try: ./compute-nova-build --help'
	}

	banner='========================== Authorized Access Notice ==================================================\nThis script is the property of Exponential Interactive Inc. Any misuse is prohibited.\n======================================================================================================'

	if [ $# -eq 1 ]
	then
        	option="${1}"

        	case ${option} in
        	-Solaris)
                	compute_flag=1
                	echo -e $banner
			sleep 3
                	;;
        	-Linux)
                	compute_flag=2
                	echo -e $banner
			sleep 3
                	;;
        	--help)
                	echo -e '\nUsage: \n\tFor Solaris zone use:\n\t\t./compute-nova-build -Solaris \n\tFor Non-Solaris Zone use:\n\t\t./compute-nova-build -Linux'
                	;;
        	*)
                	false
                	;;
        	esac
	else
        	false
	fi


	#version=$(lsb_release -d|awk '{print $2,$3}')
	version=$(lsb_release -d|awk '{print $2,$3}'|cut -d '.' -f1)

	if [ "$version" == "Ubuntu 14" ]
	then
			echo "You are using: "
			echo "-----------------------------------------"
			lsb_release -a
			echo "------------------------------------------"
			echo  "Please make sure, script is execiuted with admin privileges ...... "
			id|grep 0
			if [ $? -eq 0 ]
			then
			 	[ $compute_flag -eq 1 ] && echo "Proceding with Building a compute node in Solaris Zone ...... " || echo " "
				[ $compute_flag -eq 2 ] && echo "Proceding with Building a compute node in Linux Zone ...... " || echo " "
				echo  " "
				exit_flag=0
			else
				echo "Logged in user is not admin user"
				echo "Exiting from script ..... "
				exit_flag=1
				if [ $exit_flag -eq 1 ]
				then 
					exit 1
				fi

			fi
	else
		echo "You are not using Ubuntu 14"
		echo "This script is custome build for only Ubuntu 14"
		echo "Exiting script ......... "
		exit_flag=1
		if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi
	fi

}



installation_packages () {

                echo "======================================================================================================"
                echo "Doing Ubuntu Distro Update ............"
                echo "======================================================================================================"

                sudo apt-get update

                if [ $? -eq 0 ]
		then
			exit_flag=0 
			echo "======================================================================================================" 
			echo "Doing Ubuntu Distro Updated ............" 
			echo "======================================================================================================" 
		else
			echo "########################## Ubuntu Distro Upgrade failed ##############################################" 
			exit_flag=1
		fi

                if [ $exit_flag -eq 1 ]
		then 
			exit 1
		fi

                echo "======================================================================================================"
                echo "Installing software-properties-common ............"
                echo "======================================================================================================"
                sudo apt-get install -y software-properties-common

                if [ $? -eq 0 ]
		then
			exit_flag=0
			echo "======================================================================================================" 
			echo "Installaltion of software-properties-common successful ............"
			echo "======================================================================================================" 
		else
			echo "########################## Installation of software-properties-common unsuccessful ##############################################"
			exit_flag=1
		fi

                if [ $exit_flag -eq 1 ]
		then 
			exit 1
		fi

                echo "Adding Repository: cloud-archive:liberty "
                sudo add-apt-repository -y cloud-archive:liberty

                if [ $? -eq 0 ] 
		then
			exit_flag=0
			echo "======================================================================================================"
			echo "Added Repository: Cloud-archieve:liberty"
			echo "======================================================================================================"
		else
			echo "########################## Failed: Could not add cloud-archive:liberty  ##############################################" 
			exit_flag=1
		fi

                if [ $exit_flag -eq 1 ]
		then 
			exit 1
		fi

                echo "======================================================================================================"
                echo "Running Ubuntu Distro Update & Upgrade ............"
                echo "======================================================================================================"

                sudo apt-get update && apt-get -y dist-upgrade

                if [ $? -eq 0 ] 
		then
			exit_flag=0 
			echo "======================================================================================================" 
			echo "Ubuntu Distro Update & Upgrade successful  ............" 
			echo "======================================================================================================" 
		else
			echo "##########################Failed: Ubuntu Distro Update & Upgrade unsuccessful  ##############################################"
			exit_flag=1
		fi


                if [ $exit_flag -eq 1 ]
		then 
			exit 1
		fi

                echo "======================================================================================================"
                echo "Installing nova-compute nova-api-metadata nova-novncproxy  ............"
                echo "======================================================================================================"

                sudo apt-get install -y nova-compute nova-api-metadata nova-novncproxy

                if [ $? -eq 0 ] 
		then
			exit_flag=0 
			echo "======================================================================================================" 
			echo "Installaltion of nova-compute nova-api-metadata nova-novncproxy successful ............" 
			echo "======================================================================================================" 
		else
			echo "########################## Installation of nova-compute nova-api-metadata nova-novncproxy unsuccessful ##############################################" 
			exit_flag=1
		fi

                if [ $exit_flag -eq 1 ]
		then 
			exit 1
		fi

                echo "======================================================================================================"
                echo "Installing kvm libvirt-bin pm-utils  ............"
                echo "======================================================================================================"

                sudo apt-get install -y kvm libvirt-bin pm-utils

                if [ $? -eq 0 ]
		then
			exit_flag=0
			echo "======================================================================================================"
			echo "Installaltion of kvm libvirt-bin pm-utils successful ............" 
			echo "======================================================================================================" 
		else
			echo "########################## Installation of kvm libvirt-bin pm-utils unsuccessful ##############################################" 
			exit_flag=1
		fi


                if [ $exit_flag -eq 1 ]
		then 
			exit 1
		fi

                echo "======================================================================================================"
                echo "Installing cpu-checker ............"
                echo "======================================================================================================"

                sudo apt-get install -y cpu-checker

                if [ $? -eq 0 ]
		then
			exit_flag=0
			echo "======================================================================================================" 
			echo "Installaltion of cpu-checker successful ............" 
			echo "======================================================================================================"
		else
			echo "########################## Installation of cpu-checker unsuccessful ##############################################" 
			exit_flag=1
		fi


                if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi

                echo "======================================================================================================"
                echo "Installing ntp (Network Time Protocol)  ............"
                echo "======================================================================================================"

                sudo apt-get install -y ntp

                if [ $? -eq 0 ]
		then
			exit_flag=0 
			echo "======================================================================================================"
			echo "Installaltion of ntp successful ............"
			echo "======================================================================================================" 
		else
			echo "########################## Installation of ntp unsuccessful ##############################################" 
			exit_flag=1
		fi


                if [ $exit_flag -eq 1 ]
		then 
			exit 1
		fi

                echo "======================================================================================================"
                echo "Installing nfs-common ............"
                echo "======================================================================================================"

                sudo apt-get install -y nfs-common

                if [ $? -eq 0 ] 
		then
			exit_flag=0
			echo "======================================================================================================" 
			echo "Installaltion of nfs-common successful ............" 
			echo "======================================================================================================" 
		else
			echo "########################## Installation of nfs-common unsuccessful ##############################################" 
			exit_flag=1
		fi


                if [ $exit_flag -eq 1 ] 
		then 
			exit 1
		fi


                echo "====================================================================================================================="
                echo "Installing openvswitch-switch neutron-metadata-agent neutron-l3-agent neutron-plugin-linuxbridge-agent .............."
                echo "====================================================================================================================="

                sudo apt-get install -y openvswitch-switch neutron-metadata-agent neutron-l3-agent neutron-plugin-linuxbridge-agent

                if [ $? -eq 0 ]
		then
			exit_flag=0 
			echo "======================================================================================================" 
			echo "Installaltion of openvswitch-switch neutron-metadata-agent neutron-l3-agent neutron-plugin-linuxbridge-agent successful ............" 
			echo "======================================================================================================" 
		else
			echo "########################## Installation of openvswitch-switch neutron-metadata-agent neutron-l3-agent neutron-plugin-linuxbridge-agent unsuccessful ##############################################" 
			exit_flag=1
		fi

		if [ $exit_flag -eq 1 ]
                then
                        exit 1
                fi

		echo "====================================================================================================================="
                echo "Installing Ceilometer .............."
                echo "====================================================================================================================="

                sudo apt-get install -y ceilometer-agent-compute

                if [ $? -eq 0 ]
                then
                        exit_flag=0
                        echo "======================================================================================================" 
                        echo "Installaltion of Ceilometer successful ............" 
                        echo "======================================================================================================" 
                else                       
		 	echo "########################## Installation of Ceilometer unsuccessful ##############################################" 
                        exit_flag=1
                fi

		if [ $exit_flag -eq 1 ]
                then
                        exit 1
                fi


                echo "====================================================================================================================="
                echo "Installing SNMP  .............."
                echo "====================================================================================================================="

                sudo apt-get install -y snmp snmp-mibs-downloader snmpd

                if [ $? -eq 0 ]
                then
                        exit_flag=0
                        echo "======================================================================================================" 
                        echo "Installaltion of snmp snmp-mibs-downloader snmpd successful ............" 
                        echo "======================================================================================================" 
                else
                        echo "########################## Installation of snmp snmp-mibs-downloader snmpd unsuccessful ##############################################" 
                        exit_flag=1
                fi


                if [ $exit_flag -eq 1 ]
		then
			exit 1
		fi


		echo "====================================================================================================================="
                echo "Installing unzip  .............."
                echo "====================================================================================================================="

		sudo apt-get install -y unzip

		if [ $? -eq 0 ]
                then
                        exit_flag=0
                        echo "======================================================================================================"
                        echo "Installaltion of unzip successful ............"
                        echo "======================================================================================================"
                else
                        echo "########################## Installation of unzip unsuccessful ##############################################"
                        exit_flag=1
                fi


                if [ $exit_flag -eq 1 ]
                then
                        exit 1
                fi

		echo "====================================================================================================================="
                echo "Installing python-openstackclient  .............."
                echo "====================================================================================================================="

		sudo apt-get install -y python-openstackclient	
	
		if [ $? -eq 0 ]
                then
                        exit_flag=0
                        echo "======================================================================================================"
                        echo "Installaltion of python-openstackclient successful ............"
                        echo "======================================================================================================"
                else
                        echo "########################## Installation of python-openstackclient unsuccessful ##############################################"
                        exit_flag=1
                fi


                if [ $exit_flag -eq 1 ]
                then
                        exit 1
                fi

		echo "====================================================================================================================="
                echo "Installing python-ipcalc .............."
                echo "====================================================================================================================="

                sudo apt-get install -y python-ipcalc

                if [ $? -eq 0 ]
                then
                        exit_flag=0
                        echo "======================================================================================================"
                        echo "Installaltion of python-ipcalc successful ............"
                        echo "======================================================================================================"
                else
                        echo "########################## Installation of python-ipcalc unsuccessful ##############################################"
                        exit_flag=1
                fi


                if [ $exit_flag -eq 1 ]
                then
                        exit 1
                fi

		chown nova:nova /var/lib/nova/instances
		
		echo "====================================================================================================================="
                echo "Setting services to start on boot  .............."
                echo "====================================================================================================================="
		sudo update-rc.d libvirt-bin defaults  
		sudo update-rc.d libvirt-bin enable
		sudo update-rc.d snmpd defaults  
		sudo update-rc.d snmpd enable
		sudo update-rc.d nova-compute defaults 
		sudo update-rc.d nova-compute enable
		sudo update-rc.d nova-api-metadata defaults 
		sudo update-rc.d nova-api-metadata enable
		sudo update-rc.d nova-novncproxy defaults  
		sudo update-rc.d nova-novncproxy enable
		sudo update-rc.d neutron-metadata-agent  defaults  
		sudo update-rc.d neutron-metadata-agent  enable
		sudo update-rc.d neutron-plugin-linuxbridge-agent defaults  
		sudo update-rc.d neutron-plugin-linuxbridge-agent enable
		sudo update-rc.d ceilometer-agent-compute defaults  
		sudo update-rc.d ceilometer-agent-compute enable
}

ssh_keys() {

		echo "Copying authorised keys to compute node ...... "
                cp -p /tmp/ceilometer_sshkeys/authorized_keys /root/.ssh

		if [ $? -eq 0 ]
		then
			ssh_key1=1
		else
			ssh_key1=0
		fi

                cp -p /tmp/ceilometer_sshkeys/id_rsa /root/.ssh

		if [ $? -eq 0 ]
                then
                        ssh_key2=1
                else
                        ssh_key2=0
                fi

		cp -p /tmp/ceilometer_sshkeys/id_rsa.pub /root/.ssh

		if [ $? -eq 0 ]
                then
                        ssh_key3=1
                else
                        ssh_key3=0
                fi

		cp -p /tmp/ceilometer_sshkeys/known_hosts /root/.ssh

		if [ $? -eq 0 ]
                then
                        ssh_key4=1
                else
                        ssh_key4=0
                fi

                echo "Copying config file to compute node ........ "
                cp -p /tmp/ceilometer_sshkeys/config /root/.ssh

		if [ $? -eq 0 ]
                then
                        ssh_key5=1
                else
                        ssh_key5=0
                fi


		if [ $ssh_key1 -eq 1 ] && [ $ssh_key2 -eq 1 ] && [ $ssh_key3 -eq 1 ] && [ $ssh_key4 -eq 1 ] && [ $ssh_key5 -eq 1 ]
		then
			echo "All keys copied"
		else
			echo "################################################################################################"
			echo "Failure: All keyes were not copied"
			echo "Please try manually ..... "
			echo "################################################################################################"
			sleep 3
		fi

                echo "Changing /root/.ssh/authorized_keys permission set"
                chmod 644 /root/.ssh/authorized_keys
		chmod 600 /root/.ssh/id_rsa
		chmod 644 /root/.ssh/id_rsa.pub
		chmod 644 /root/.ssh/known_hosts
		chmod 644 /root/.ssh/config

		chmod 700 /root/.ssh
		
		if [ $? -eq 0 ]
		then
			echo "Successfully changes permisssions: /root/.ssh/ "
		else
			echo "There was a problem in changing permission, please check and try it manually later"
		fi
		
}

ceilometer() {

                ceilometer_dir=$(pwd)

                echo "Unziping ceilometer_sshkeys.zip ...... "

                unzip $ceilometer_dir/ceilometer_sshkeys.zip -d /tmp/ceilometer_sshkeys

                if [ $? -eq 0 ]
                then
                        exit_flag=0

			if [ -d /root/.ssh ]
			then
				ssh_keys
			else
				mkdir -p /root/.ssh
				ssh_keys
			fi

                        echo "Making ceilometer configuration changes ..... "
                        cp -p /tmp/ceilometer_sshkeys/ceilometer.conf /etc/ceilometer

                        echo "Making Ceilometer pipeline configuration changes ....... "
                        cp -p /tmp/ceilometer_sshkeys/pipeline.yaml /etc/ceilometer

                        #Following Pipeline hostname change
			#echo "Updating Ceilometer pipeline with compute IP address: $IP_Address"
                        #sed -i "s/10.28.4.38/$IP_Address/g" /etc/ceilometer/pipeline.yaml
			node_hostname=$(hostname)
			echo "Updating Ceilometer pipeline with compute Hostname:$node_hostname"
			sed -i "s/10.28.4.38/$node_hostname/g" /etc/ceilometer/pipeline.yaml
			

                        echo "Changing Ceilometer owner & group to ceilometer"
                        chown -R ceilometer:ceilometer /etc/ceilometer

                        cp -p /tmp/ceilometer_sshkeys/snmpd.conf /etc/snmp

                        rm -rf /tmp/ceilometer_sshkeys
                else
                        echo "Unable to unzip ceilometer_sshkeys.zip ...... "
                        exit_flag=1
                fi


                if [ $exit_flag -eq 1 ]
                then
                        exit 1
                fi

}

Ceilometer_and_key_exchange() {

                if [ -d /tmp/ceilometer_sshkeys ]
                then
                        ceilometer
                else
                        mkdir -p /tmp/ceilometer_sshkeys
                        ceilometer
                fi

}


        clear
	
	interface=$2

	 #Machine_IP_Address=$(ifconfig|grep -e 'inet addr'|grep -v 127|cut -d ':' -f2|cut -d ' ' -f1)
	
	#Machine_IP_Address=$(host $(uname -n)|grep 'address'|awk '{print $4}')

	Machine_IP_Address=$(ifconfig -a)

	IP_Address=$3

	Region="$4"
	
	region_flag=0

	network1=$(echo $5|cut -d ':' -f1)
	vlanid1=$(echo $5|cut -d ':' -f2)
	#echo "vlanid1: $vlanid1"

	network2=$(echo $6|cut -d ':' -f1)
	vlanid2=$(echo $6|cut -d ':' -f2)
	#echo "vlanid2: $vlanid2"

	IP_Validate=$(echo $IP_Address|grep -E -o "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)")


        false () {

                echo -e "\nIllegal parameter"
                echo -e '\n\nFor usage try: ./compute-nova-build --help'
                exit 1
        }

	seperator="======================================================================================================" 

        banner='========================== Authorized Access Notice ==================================================\nThis script is the property of Exponential Interactive Inc. Any misuse is prohibited.\n======================================================================================================'
	
	if [ $1 == "--help" ]
	then
		#echo -e '\nUsage: \n\tFor Solaris zone use:\n\t\t./compute-nova-build -solaris <data-interface-name> <IP-Address> \n\tFor Non-Solaris Zone use:\n\t\t./compute-nova-build -linux <data-interface-name> <IP-Address> \n\n\t\t\tWherein: -solaris & -linux is availability zone \n\t\t\t<data-interface-name> is free interface to be used for data \n\t\t\t<IP-Address> is IP address of compute-node like xxx.xxx.xxx.xxx' #change made for region
		#echo -e '\nUsage: \n\tFor Solaris zone use:\n\t\t./compute-nova-build -solaris <data-interface-name> <IP-Address> <region> \n\tFor Non-Solaris Zone use:\n\t\t./compute-nova-build -linux <data-interface-name> <IP-Address> <region> \n\n\t\t\tWherein: -solaris & -linux is availability zone \n\t\t\t<data-interface-name> is free interface to be used for data \n\t\t\t<IP-Address> is IP address of compute-node like xxx.xxx.xxx.xxx \n\t\t\t<region> is region: Region can be either LA or SCL1' 
		echo -e '\nUsage: \n\tFor Solaris zone use:\n\t\t./compute-nova-build -solaris <data-interface-name> <IP-Address> <region> <network1:vlanid1> <network2:vlanid2> \n\tFor Non-Solaris Zone use:\n\t\t./compute-nova-build -linux <data-interface-name> <IP-Address> <region> <network1:vlanid1> <network2:vlanid2>\n\n\t\t\tWherein: -solaris & -linux is availability zone \n\t\t\t<data-interface-name> is free interface to be used for data \n\t\t\t<IP-Address> is IP address of compute-node like xxx.xxx.xxx.xxx \n\t\t\t<region> is region: Region can be either LA1 or SCL1\n\t\t\t<network-1:vlan-id1> is network-1 and vlan-id1; Example: Prod-SCL1:132 \n\t\t\t<network-2:vlan-id2> is network-2 and vlan-id2; Example: Dev-SCL1:2048'
        	exit 1
	fi

	if [ $# -ne 6 ] #if [ $# -ne 3 ] #change made for region 
	then
		false
	fi

        if [ $# -eq 6 ] #if [ $# -eq 3 ] #change made for region
        then
                option="${1}"

                case ${option} in
                -solaris)
                        compute_flag=1

			if [ -z $2 ] || [ -z $3 ] || [ -z $4 ] #if [ -z $2 ] || [ -z $3 ] #change made for region
			then
				false
			else #This else block is for region change
				if [ "$Region" == "LA1" ]
				then
					region_flag=1
				elif [ "$Region" == "SCL1" ]
                                then
                                       	region_flag=2
				else
					echo "Region = $Region is invalid"
					echo "Valid regions are LA1 & SCL1"
					echo "Please try again .... "
					echo "Exiting from script"
					exit 1
                               	fi	
				
			fi

			echo -e $banner
			sleep 3

                        ;;
                -linux)
                        compute_flag=2

			if [ -z $2 ] || [ -z $3 ] || [ -z $4 ] #if [ -z $2 ] || [ -z $3 ] #change made for region
                        then
                                false
			else #This else block is for region change
				if [ "$Region" == "LA1" ]
                                then
                                        region_flag=1
                                elif [ "$Region" == "SCL1" ]
                                then
                                        region_flag=2
                                else
                                        echo "Region = $Region is invalid"
                                        echo "Valid regions are LA1 & SCL1"
                                        echo "Please try again .... "
                                        echo "Exiting from script"
					exit 1
                                fi
                        fi

                        echo -e $banner
			sleep 3
                        ;;
                --help)
			#echo -e '\nUsage: \n\tFor Solaris zone use:\n\t\t./compute-nova-build -solaris <data-interface-name> <IP-Address> <region> \n\tFor Non-Solaris Zone use:\n\t\t./compute-nova-build -linux <data-interface-name> <IP-Address> <region> \n\n\t\t\tWherein: -solaris & -linux is availability zone \n\t\t\t<data-interface-name> is free interface to be used for data \n\t\t\t<IP-Address> is IP address of compute-node like xxx.xxx.xxx.xxx \n\t\t\t<region> is region: Region can be either LA or SCL1'
			#echo -e '\nUsage: \n\tFor Solaris zone use:\n\t\t./compute-nova-build -solaris <data-interface-name> <IP-Address> <region> <network1:vlanid1> <network2:vlanid2> \n\tFor Non-Solaris Zone use:\n\t\t./compute-nova-build -linux <data-interface-name> <IP-Address> <region> \n\n\t\t\tWherein: -solaris & -linux is availability zone \n\t\t\t<data-interface-name> is free interface to be used for data \n\t\t\t<IP-Address> is IP address of compute-node like xxx.xxx.xxx.xxx \n\t\t\t<region> is region: Region can be either LA1 or SCL1\n\t\t\t<network-1:vlan-id1> is network-1 and vlan-id1 \n\t\t\t<network-2:vlan-id2> is network-2 and vlan-id2'
			echo -e '\nUsage: \n\tFor Solaris zone use:\n\t\t./compute-nova-build -solaris <data-interface-name> <IP-Address> <region> <network1:vlanid1> <network2:vlanid2> \n\tFor Non-Solaris Zone use:\n\t\t./compute-nova-build -linux <data-interface-name> <IP-Address> <region> \n\n\t\t\tWherein: -solaris & -linux is availability zone \n\t\t\t<data-interface-name> is free interface to be used for data \n\t\t\t<IP-Address> is IP address of compute-node like xxx.xxx.xxx.xxx \n\t\t\t<region> is region: Region can be either LA1 or SCL1\n\t\t\t<network-1:vlan-id1> is network-1 and vlan-id1; Example: Prod-SCL1:132 \n\t\t\t<network-2:vlan-id2> is network-2 and vlan-id2; Example: Dev-SCL1:2048'
                        exit 1
                        ;;
                *)
                        false
                        ;;
                esac
        else
                false
        fi
	
	echo "================================================================================================================================================================="
	echo "This script deploys compute node, Please make sure port is tagged ..... "
sleep 2 
echo "Is port is tagged ? "
echo "Enter 'Y' for 'Yes' and 'N' for 'No' : "
read user_entry;

if [ $user_entry == 'Y' ] || [ $user_entry == 'Yes' ] || [ $user_entry == 'yes' ] || [ $user_entry == 'YES' ] || [ $user_entry == 'y' ]
then
        echo "Port is tagged, continuing with compute node installtion ...... "
elif [ $user_entry == 'N' ] || [ $user_entry == 'No' ] || [ $user_entry == 'no' ] || [ $user_entry == 'NO' ] || [ $user_entry == 'n' ]
then
        echo "Port is not tagged, compute node installation aborted ..... "
        echo "Exiting from script ...... "
        exit 1
else
        echo "Invalid user input ....."
        echo "Please try again ......"
        echo "Exiting from script ...... "
        exit 1
fi

if [ $user_entry == 'N' ] || [ $user_entry == 'No' ] || [ $user_entry == 'no' ] || [ $user_entry == 'NO' ]
then
        echo "Port is not tagged, continuing with compute node aborted ..... "
        echo "Exiting from script ...... "
        exit 1
fi

echo "Verifying DNS entries for console: Please enter console name: (example bc7-b9-console)"

read console

echo $console|grep console

if [ $? -eq 0 ]
then
	echo "Checking $console for DNS entry"
else
	echo "Console $console doesnot exist"
	echo "Exiting from script ...... "
	exit 1
fi	

/usr/bin/nslookup $console

if [ $? -eq 0 ]
then
	echo "DNS entry for console $console found ..... "
	echo "Proceeding with compute node installation .... "
else
	echo "Failure: DNS entry for console $console not found ..... "
	echo "Compute node instalaltion aborted ..... "
	echo "Exiting from script ...... "
        exit 1
fi	
	
	echo "================================================================================================================================================================="

	re='^[0-9]+$'
	
	if ! [[ $vlanid1 =~ $re ]] ; then
   		echo "Error: Invalid input" 
		echo "vlanid1: $vlanid1 should only be a integer number"
		echo "Exiting from script"
		exit 1
	fi

	if ! [[ $vlanid2 =~ $re ]] ; then
		echo "Error: Invalid input"
                echo "vlanid2: $vlanid2 should only be a integer number"
                echo "Exiting from script"
                exit 1
        fi

        if [ $vlanid1 -gt 4095 ]  || [ $vlanid1 -eq 0 ]
        then
                echo "Entered vlan-id1:$vlanid1 is either 0 or more than 4095"
                echo "This value is invalid ......."
                echo "Exiting from script ......"
                exit 1
        fi

        if [ $vlanid2 -gt 4095 ] || [ $vlanid2 -eq 0 ]
        then
                echo "Entered vlan-id2:$vlanid2 is either 0 or more than 4095"
                echo "This value is invalid ......."
                echo "Exiting from script ......"
                exit 1
        fi

	interface_status=$(ip a s|grep $interface|grep -w UP|wc -l)

	

        if [ $interface_status -gt 0 ]
        then
                echo "Interface: $interface is present and currently up ..... "
        else
                interface_check=$(ip a s|grep $interface|wc -l)
                if [ $interface_check -gt 0 ]
                then
                        echo "Interface: $interface is present ..... "
                        echo "Trying to change its state from DOWN to UP ...... "
                        ifconfig $interface up
                        if [ $? -eq 0 ]
                        then
                                echo "Interface: $interface is UP now .... "
                        else
                                echo "Failure: Not able to change status of interface: $interface from DOWN to UP ........ "
                                echo "Exiting from script ..... "
                                exit 1
                        fi

                else
                        echo "Interface: $interface is not present ..... "
                        echo "Exiting from script ..... "
                        exit 1
                fi
        fi

	if [ -z $IP_Validate ]
        then
                echo "$IP_Address is not a valid IP Address"
                echo " "
                echo "Please enter a valid IP Address, and try again ......"
                echo " "
                echo "For more information, try ./compute-nova-build --help" 
                echo " "
                echo "Exiting from script"
                echo " "
                exit 1
        else
                if [ "$IP_Validate" == "$IP_Address" ]
                then
                        echo " "
                else
                        echo "IP Address: $IP_Address is not a valid IP Address"
                        echo " "
                        echo "Please enter a valid IP Address, and try again ......"
                        echo " "
                        echo "For more information, try ./compute-nova-build --help"
                        echo " "
                        echo "Exiting from script"
                        exit 1
                fi
        fi


	IP_Check=$(echo $Machine_IP_Address | grep -w "$IP_Address" |wc -l)

        if [ $IP_Check -gt 0 ]
        then
                echo " "
        else
		echo "IP Address: $IP_Address is not presnt on machine"
                echo " "
                exit 1
        fi


        #version=$(lsb_release -d|awk '{print $2,$3}')
	version=$(lsb_release -d|awk '{print $2,$3}'|cut -d '.' -f1)

        if [ "$version" == "Ubuntu 14" ]
        then
                        echo "You are using: "
                        echo "-----------------------------------------"
                        lsb_release -a
                        echo "------------------------------------------"
                        echo  "Please make sure, script is execiuted with admin privileges ...... "
                        id|grep 0
                        if [ $? -eq 0 ]
                        then
                                [ $compute_flag -eq 1 ] && echo "Proceding with Building a compute node in Solaris Zone ...... " || echo " "
                                [ $compute_flag -eq 2 ] && echo "Proceding with Building a compute node in Linux Zone ...... " || echo " "
                                echo  " "
                        else
                                echo "Logged in user is not admin user"
                                echo "Exiting from script ..... "
                                exit 1
                        fi
        else
                echo "You are not using Ubuntu 14"
                echo "This script is custome build for only Ubuntu 14"
                echo "Exiting script ......... "
                exit 1
        fi


	export OS_PROJECT_DOMAIN_ID=default
	export OS_USER_DOMAIN_ID=default
	export OS_PROJECT_NAME=admin
	export OS_TENANT_NAME=admin
	export OS_USERNAME=admin
	export OS_PASSWORD=0penst@ck
	export OS_AUTH_URL=http://expostack.tf-net.tribalfusion.com:35357/v3
	#export OS_AUTH_URL=http://controller:35357/v3
	export OS_IDENTITY_API_VERSION=3
	export PS1='[\u@\h \W(admin)]\$ '


apt_proxy_changes && echo $seperator && echo $seperator && admin_permission && echo $seperator && echo $seperator && installation_packages && echo $seperator && echo $seperator && mount_compute && echo $seperator && echo $seperator && kvm_compliance && configuration_files && echo $seperator && echo $seperator && configuration_IP_Change && change_hosts_controller && echo $seperator && echo $seperator && qemu_configuration && migration_enable && echo $seperator && echo $seperator && libvirtd_configurartion && echo $seperator && echo $seperator && destroy_virtual_bridge && echo $seperator && echo $seperator && network_time_configuration && echo $seperator && echo $seperator && configure_VLAN && echo $seperator && echo $seperator && configure_nova_distribution_package && echo $seperator && echo $seperator && Ceilometer_and_key_exchange && echo $seperator && echo $seperator && region && echo $seperator && echo $seperator && net_filter_config && echo $seperator && echo $seperator && restart_services && echo $seperator && echo $seperator && salt_install

####Following is Ceilometer change #GIT-940
cd /var/lib/nova/instances/ceilometer_zenoss-1.1.0dev
./zenoss_compute.sh

INTERFACE_LIST=$(dmesg |grep 'NIC Link' |awk '{print $5}'|cut -d ':' -f 1|sort -u)
for i in $INTERFACE_LIST;do
if [ $(grep auto /etc/network/interfaces|grep $i|wc -l) -gt 0 ]
then
        continue
else
	echo "auto $i" >> /etc/network/interfaces
fi
done

#Compute node addition to admin aggregate GIT-940
echo "Adding compute node to admin aggregate"
openstack aggregate add host 7 $(uname -n)

if [ $? -eq 0 ]
then
	echo "Compute node is added to admin aggregate"
else
	echo "Compute node was not added to admin aggregate"
fi

####################################################################################################################################################
#Following code adds computes to aggregate host
#if [ $compute_flag -eq 1 ]
#then
#	#echo "Solaris"
#	echo "Adding compute node to aggregate - AGG2-SCL1-QEMU - SCL1-ZONE2(Solaris only) "
#	openstack aggregate add host 2 $(uname -n)
#	if [ $? -eq 0 ]
#        then
#                        echo "Compute node added to AGG2-SCL1-QEMU - SCL1-ZONE2(Solaris only)"
#        else
#                        echo "Failure: Compute created but failed to add compute node to AGG2-SCL1-QEMU - SCL1-ZONE2(Solaris only)"
#                        echo "Please check logs and try manually ...... "
#                        echo "Exiting from script ..... "
#                        exit 1
#        fi
#else
#	if [ $compute_flag -eq 2 ]
#	then
#		#echo "Linux"
#		echo "Adding compute node to aggregate - AGG1-SCL1-KVM - SCL1-ZONE1(Windows and Linux)"
#		openstack aggregate add host 1 $(uname -n)
#		if [ $? -eq 0 ]
#		then
#			echo "Compute Node $(uname -n) has been successfully created "
#			echo "Compute node added to AGG1-SCL1-KVM - SCL1-ZONE1(Windows and Linux)"
#		else
#			echo "Compute Node $(uname -n) has been successfully created "
#			echo "Failure: Could not add Compute Node $(uname -n) to AGG1-SCL1-KVM - SCL1-ZONE1(Windows and Linux)"
#			echo "Please check logs and try to add manually after reboot...... "
#		fi		
#	fi
#fi
####################################################################################################################################################
	
echo "Compute will reboot now ......... " && sleep 30 && reboot

